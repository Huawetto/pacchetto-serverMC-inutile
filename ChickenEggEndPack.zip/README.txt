Chicken Egg End resource pack

Files:
  - assets/minecraft/textures/item/chicken_egg_end_lava.png
  - assets/minecraft/models/item/chicken_egg_end.json
  - assets/minecraft/models/item/dragon_egg.json (legacy override fallback)
  - assets/minecraft/items/dragon_egg.json (1.21.4+ style guess)

This pack only changes DRAGON_EGG items that have CustomModelData = 900001.

Install:
  1. Zip is already ready to upload.
  2. Host the zip on a direct-download URL.
  3. Put the URL into server.properties resource-pack=
  4. Put the SHA1 of the zip into server.properties resource-pack-sha1=
  5. Optional: require-resource-pack=true

Note:
  This environment could not fetch Mojang's official 1.21.11 lava texture file directly,
  so the included PNG is a lava-style replacement prepared for the custom egg item only.
  If you later extract the exact vanilla 1.21.11 lava texture from the client assets,
  replace chicken_egg_end_lava.png with that file.
